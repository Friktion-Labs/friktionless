__doc__ = """ """

import friktionless.zaps
# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['friktionless']

package_data = \
{'': ['*']}

install_requires = \
['altair-saver>=0.5.0,<0.6.0',
 'altair>=4.2.0,<5.0.0',
 'google-cloud-bigquery>=3.1.0,<4.0.0',
 'google-cloud-storage>=2.3.0,<3.0.0',
 'pandas-gbq>=0.17.5,<0.18.0',
 'pandas>=1.4.2,<2.0.0',
 'selenium>=4.1.5,<5.0.0']

setup_kwargs = {
    'name': 'friktionless',
    'version': '0.0.1',
    'description': '**friktionless** is a Python package providing simplified interfaces to Friktion data. It aims to be the fundamental building block for doing data engineering and data analysis in Python for Friktion. Additionally, it has the broader goal of becoming **the most powerful and flexible open.',
    'long_description': None,
    'author': 'Matt Martin',
    'author_email': 'matt@friktionlabs.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
